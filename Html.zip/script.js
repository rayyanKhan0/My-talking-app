// HTML
<html>
<head>
  <style>
    #gameArea {
      position: relative;
      width: 400px;
      height: 400px;
      border: 1px solid black;
    }
    #square {
      position: absolute;
      width: 50px;
      height: 50px;
      background-color: blue;
      top: 0;
    }
    .block {
      position: absolute;
      width: 50px;
      height: 50px;
      background-color: red;
    }
    #loseScreen {
      display: none;
    }
  </style>
</head>
<body>
  <div id="gameArea">
    <div id="square"></div>
  </div>
  <div id="loseScreen">
    <h1>You Lose!</h1>
    <button id="replayBtn">Replay</button>
  </div>

  <script src="script.js"></script>
</body>
</html>

// JavaScript
const gameArea = document.getElementById('gameArea');
const square = document.getElementById('square');
const replayBtn = document.getElementById('replayBtn');
const loseScreen = document.getElementById('loseScreen');
let gameIsLost = false;

gameArea.addEventListener('click', moveUp);
gameArea.addEventListener('mousedown', moveUp);
gameArea.addEventListener('mouseup', moveDown);

function moveUp() {
  if (!gameIsLost) {
    square.style.top = `${parseInt(square.style.top) - 10}px`;
  }
}

function moveDown() {
  if (!gameIsLost) {
    square.style.top = `${parseInt(square.style.top) + 10}px`;
  }
}

function checkCollision() {
  const blocks = document.getElementsByClassName('block');
  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    const squarePosition = square.getBoundingClientRect();
    const blockPosition = block.getBoundingClientRect();
    if (
      squarePosition.top < blockPosition.bottom &&
      squarePosition.right > blockPosition.left &&
      squarePosition.bottom > blockPosition.top &&
      squarePosition.left < blockPosition.right
    ) {
      loseGame();
    }
  }
}

function createBlock() {
  const block = document.createElement('div');
  block.classList.add('block');
  block.style.left = `${Math.random() * (gameArea.offsetWidth - 50)}px`;
  gameArea.appendChild(block);
}

function loseGame() {
  gameIsLost = true;
  loseScreen.style.display = 'block';
}

replayBtn.addEventListener('click', () => {
  loseScreen.style.display = 'none';
  gameIsLost = false;
  square.style.top = '0';
  const blocks = document.getElementsByClassName('block');
  while (blocks.length > 0) {
    blocks[0].parentNode.removeChild(blocks[0]);
  }
});

setInterval(createBlock, 1000);
setInterval(checkCollision, 100);

